dmg=0;
