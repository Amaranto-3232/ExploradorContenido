part_particles_create(global.part_front,x,y,global.p_pistol,20);
