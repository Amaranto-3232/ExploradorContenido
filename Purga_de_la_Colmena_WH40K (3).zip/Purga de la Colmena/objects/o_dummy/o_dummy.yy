{
  "$GMObject": "",
  "%Name": "o_dummy",
  "eventList": [
    {
      "$GMEvent": "v1",
      "%Name": "",
      "collisionObjectId": null,
      "eventNum": 0,
      "eventType": 0,
      "isDnD": false,
      "name": "",
      "resourceType": "GMEvent",
      "resourceVersion": "2.0"
    }
  ],
  "managed": true,
  "name": "o_dummy",
  "overriddenProperties": [],
  "parent": {
    "name": "enemies",
    "path": "folders/Objects/enemies.yy"
  },
  "parentObjectId": {
    "name": "o_enemy_body",
    "path": "objects/o_enemy_body/o_enemy_body.yy"
  },
  "persistent": false,
  "physicsAngularDamping": 0.1,
  "physicsDensity": 0.5,
  "physicsFriction": 0.2,
  "physicsGroup": 1,
  "physicsKinematic": false,
  "physicsLinearDamping": 0.1,
  "physicsObject": false,
  "physicsRestitution": 0.1,
  "physicsSensor": false,
  "physicsShape": 1,
  "physicsShapePoints": [],
  "physicsStartAwake": true,
  "properties": [],
  "resourceType": "GMObject",
  "resourceVersion": "2.0",
  "solid": false,
  "spriteId": {
    "name": "s_dummy",
    "path": "sprites/s_dummy/s_dummy.yy"
  },
  "spriteMaskId": null,
  "visible": true
}