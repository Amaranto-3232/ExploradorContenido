target_room = room;
