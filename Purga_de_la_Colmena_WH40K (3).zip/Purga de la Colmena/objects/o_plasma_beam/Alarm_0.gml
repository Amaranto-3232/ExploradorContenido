dmg = 0;
