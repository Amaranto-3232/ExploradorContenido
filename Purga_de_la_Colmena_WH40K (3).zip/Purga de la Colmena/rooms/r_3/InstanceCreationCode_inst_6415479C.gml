target_room = r_boss;
