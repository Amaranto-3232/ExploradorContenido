{
  "$GMScript": "v1",
  "%Name": "c_flip",
  "isCompatibility": false,
  "isDnD": false,
  "name": "c_flip",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}