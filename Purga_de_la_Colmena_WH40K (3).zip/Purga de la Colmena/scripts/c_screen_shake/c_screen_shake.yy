{
  "$GMScript": "v1",
  "%Name": "c_screen_shake",
  "isCompatibility": false,
  "isDnD": false,
  "name": "c_screen_shake",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}