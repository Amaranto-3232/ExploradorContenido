{
  "$GMScript": "v1",
  "%Name": "c_weapon_bolter",
  "isCompatibility": false,
  "isDnD": false,
  "name": "c_weapon_bolter",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}